filename = 'text_exs_files/programming_poll.txt'

responses = []
while True:
    response = input("\nWhy do you like programming? ")
    responses.append(response)

    continue_poll = input("Would you like to let someone else respond? (y/n) ")
    if continue_poll.lower() not in {'y', 'yes', 'yeap', 'ok'}:
        break

with open(filename, 'w+') as f:
    for i, response in enumerate(responses):
        f.write(f"{response}\n")


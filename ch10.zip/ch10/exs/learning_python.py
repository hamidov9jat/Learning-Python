filename = 'text_exs_files/learning_python.txt'

print("--- Reading in the entire file:")
with open(filename) as f:
    # contents = f.read(0)
    contents = f.read()
# print(repr(contents))
print(contents)
print("\n--- Looping over the lines:")
with open(filename) as f:
    for line in f:
        print(line.rstrip())

print("\n--- Storing the lines in a list:")
with open(filename) as f:
    lines = f.readlines()
print(lines)

for line in lines:
    print(line.rstrip())

print("------------------")
myfile = open("text_exs_files/learning_python.txt", "r")
myline = myfile.readline().rstrip()
while myline:
    print(myline)
    myline = myfile.readline().rstrip()
myfile.close()

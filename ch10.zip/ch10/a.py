file_path = 'text_files/pi_digits.txt'
with open(file_path) as file_object:
    # contents = file_object.read()
    # print(contents.rstrip())
    # for line in file_object:
    #     print((line.rstrip()))
    lines = file_object.readlines()

pi_string = ''
for line in lines:
    # pi_string += line.rstrip()
    pi_string += line.strip()

print(pi_string)
pi_number = float(pi_string)
print(pi_number)
# print(f"{pi_string[:52]}...")
print(f"Length of the string is {len(pi_string)}")

# for line in lines:
#     print(line.rstrip())

# print(contents)
# print("_________________________")
# print(contents.rstrip())
# print(repr(contents.rstrip()))
# print("_________________________")
#
# print(repr(contents))
